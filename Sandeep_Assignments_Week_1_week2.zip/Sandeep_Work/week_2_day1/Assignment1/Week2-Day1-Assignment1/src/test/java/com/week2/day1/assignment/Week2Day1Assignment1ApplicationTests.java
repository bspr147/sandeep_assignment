package com.week2.day1.assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week2Day1Assignment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
