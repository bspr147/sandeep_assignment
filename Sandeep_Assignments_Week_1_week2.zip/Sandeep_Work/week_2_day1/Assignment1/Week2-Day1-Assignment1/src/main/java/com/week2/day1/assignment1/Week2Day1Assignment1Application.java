package com.week2.day1.assignment1;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Week2Day1Assignment1Application {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext actx = new AnnotationConfigApplicationContext(EmployeeConfiguration.class);
		
		EmployeeConfiguration eConfi = (EmployeeConfiguration) actx.getBean("eConfig");
		
		eConfi.display();
		
		
		actx.close();
	}

}
