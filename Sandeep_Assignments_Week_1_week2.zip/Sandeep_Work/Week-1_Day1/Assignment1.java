package Day1;
class A{
	int count=0;
	
}

public class Assignment1 {

	public static void main(String[] args) throws  Exception{
		// TODO Auto-generated method stub
		A n = new A();
		System.out.println(n.getClass().getName());
	}

}