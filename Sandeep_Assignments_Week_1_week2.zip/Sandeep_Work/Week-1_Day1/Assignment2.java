package Day1;

import java.util.ArrayList;
import java.util.List;

 class X {
	
 }
 
  class Y extends X {

	 static public void get() {
		
		
		 
		 class p1{
			
			
		}
	}
	
  }

 public class Assignment2 {
	
	public static void main(String[] args) {
		
		Y y= new Y();
		List<X> list = new ArrayList<X>();
		
		list.add((X)y);
		
		
	}

}
