package Day2;

public class Assignment5A {

	public static void main(String[] args) {
		
		System.out.println(Assignment5.Instance.hashCode());
		System.out.println(Assignment5.Instance.hashCode());
		
	}
	
}
