package Day2;

public enum Assignment5 {
	
	Instance;
	
	private Assignment5() {
		
	}

}
