package com.week2.day2.assignment3.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.week2.day2.assignment3.Employee;
import com.week2.day2.assignment3.repository.EmployeeRepository;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeRepository empRepo;;

	@GetMapping("/all")
	public List<Employee> getEmployees() {
		return empRepo.getAllEmployees();
	}

	@GetMapping("/{emp_id}")
	public Employee getEmployeeById(@PathVariable Integer emp_id) {
		return empRepo.getEmployeeById(emp_id);
	}

	@GetMapping("/get")
	public Employee getEmployee(@RequestParam("id") Integer id) {
		return empRepo.getEmployeeById(id);
	}

	@PostMapping("/add")
	public Employee addEmployee(@RequestBody Employee emp) {
		return empRepo.addEmployee(emp);
	}

	@PutMapping("/update/{id}")
	public Employee updateEmployee(@PathVariable("id") Integer emp_id, @RequestBody Employee emp) {
		Employee emp1 = getEmployeeById(emp_id);
		emp1.setEmp_name(emp.getEmp_name());
		emp1.setEmp_sal(emp.getEmp_sal());
		return emp1;
	}

	@DeleteMapping("/{emp_id}")
	public String removeEmployeeById(@PathVariable Integer emp_id) {
		return empRepo.deleteEmployee(emp_id);
	}

}
