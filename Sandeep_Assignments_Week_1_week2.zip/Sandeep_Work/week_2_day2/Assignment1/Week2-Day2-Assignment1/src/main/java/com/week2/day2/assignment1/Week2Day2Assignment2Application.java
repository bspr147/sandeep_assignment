package com.week2.day2.assignment1;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/*#1. In COmponentScan example provided, try to Autowire B in A. Add display() method in B,
 *   and invoke it from display method of A. Invoke display method of A, from main application.
 */
@Configuration
@ComponentScan(basePackages = { "com.week2.day2.assignment1" })
public class Week2Day2Assignment2Application {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(
				Week2Day2Assignment2Application.class);

		A oa = (A) ctx.getBean("abean", "This is to test");
		System.out.println(oa);
		oa.display();
		System.out.println("*****************************");
		Employee emp = (Employee) ctx.getBean("empp", oa);
		emp.setName("pqrst");
		System.out.println(emp.getName());
		System.out.println("*****************************");

		emp.print();
		
		ctx.close();
	}

}
