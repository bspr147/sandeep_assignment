package com.week2.day2.assignment1;

import org.springframework.stereotype.Component;

@Component
public class B {
	
	public B() {
		System.out.println("B() constructor !!!");
	}
	
	public void display() {
		System.out.println("B class - display method !!!!!");
	}
}
