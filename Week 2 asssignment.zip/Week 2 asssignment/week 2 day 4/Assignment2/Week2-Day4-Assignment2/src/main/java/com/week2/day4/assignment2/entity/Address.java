package com.week2.day4.assignment2.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table
public class Address {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long h_no;
	private String city;
	private String district;
	private String state;
	private Long pincode;
	
	
	
	public Address() {
	}

	public Address(Long h_no, String city, String district, String state, Long pincode) {
		this.h_no = h_no;
		this.city = city;
		this.district = district;
		this.state = state;
		this.pincode = pincode;
	}

	public Long getH_no() {
		return h_no;
	}

	public void setH_no(Long h_no) {
		this.h_no = h_no;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getPincode() {
		return pincode;
	}

	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [h_no=" + h_no + ", city=" + city + ", district=" + district + ", state=" + state + ", pincode="
				+ pincode + "]";
	}

}
