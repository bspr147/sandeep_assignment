package com.week2.day4.assignment2.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.week2.day4.assignment2.service.EmployeeServiceImpl;

@Configuration
public class EmployeeConfiguration {
	
	@Bean
	public EmployeeServiceImpl getMethod() {
		return new EmployeeServiceImpl(10);
	}

}
