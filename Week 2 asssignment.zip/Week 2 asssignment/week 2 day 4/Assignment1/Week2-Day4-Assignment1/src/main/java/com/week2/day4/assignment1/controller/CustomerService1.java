package com.week2.day4.assignment1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.week2.day4.assignment1.model.Customer;
import com.week2.day4.assignment1.repository.CustomerRepository;

@Service
public class CustomerService1 {
	
	@Autowired
	private CustomerService2 service2;
	
	@Autowired
	private CustomerRepository repository;
	
	@SuppressWarnings("unused")
	@Transactional(isolation = Isolation.DEFAULT, propagation = Propagation.REQUIRES_NEW)
	public Customer internalMethod(Customer customer) throws Exception
	{
		Customer _customer = repository.save(new Customer(customer.getName()+" internal", customer.getAge()));
		//not committed
		
		service2.internalMethod1(customer);
		//Committed
		
		if(true) {
		//throw exception so that book will not save in DB
		throw new Exception("this exception in throwing intentionally");
		}
		
		return _customer;
	}

}
