package com.week2.day4.assignment1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.week2.day4.assignment1.model.Customer;
import com.week2.day4.assignment1.repository.CustomerRepository;

@Service
public class CustomerService2 {
	
	@Autowired
	private CustomerRepository repository;
	
	
	@Transactional(isolation = Isolation.DEFAULT, propagation = Propagation.REQUIRES_NEW)
	//You may also check behavior with Propogation.REQUIRED, MANDATORY, NOT_SUPPORTED, NEVER
	public Customer internalMethod1(Customer customer)
	{
		Customer _customer = repository.save(new Customer(customer.getName()+" outer", customer.getAge()));
		//since new transaction is started, above record gets saved as no exceptions are thrown here
		return _customer;
	}
}
