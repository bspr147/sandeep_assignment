package com.week2.day1.assignment2.model;

public class Address {

	private Integer h_no;
	private String city;
	private String district;
	private Integer zip;
	
	public Address() {
		System.out.println("Address() constructor");
	}

	public Address(Integer h_no, String city, String district, Integer zip) {
		this.h_no = h_no;
		this.city = city;
		this.district = district;
		this.zip = zip;
	}

	public Integer getH_no() {
		return h_no;
	}

	public void setH_no(Integer h_no) {
		this.h_no = h_no;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public Integer getZip() {
		return zip;
	}

	public void setZip(Integer zip) {
		this.zip = zip;
	}

	@Override
	public String toString() {
		return "Address [h_no=" + h_no + ", city=" + city + ", district=" + district + ", zip=" + zip + "]";
	}
	
}
