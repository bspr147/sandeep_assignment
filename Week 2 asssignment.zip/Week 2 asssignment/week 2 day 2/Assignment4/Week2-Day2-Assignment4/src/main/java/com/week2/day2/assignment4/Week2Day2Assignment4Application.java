package com.week2.day2.assignment4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*#4. In Spring Boot REST application, 
 * use ResponseEntity, to send custom headers,
 *  status code along with response body to client. Share screenshot of PostMan.*/

@SpringBootApplication
public class Week2Day2Assignment4Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day2Assignment4Application.class, args);
	}

}
