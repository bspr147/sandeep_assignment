package com.week2.day2.assignment4.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.week2.day2.assignment4.entity.Employee;

@Repository
public interface EmployeeRepo extends JpaRepository<Employee, Integer> {


}
