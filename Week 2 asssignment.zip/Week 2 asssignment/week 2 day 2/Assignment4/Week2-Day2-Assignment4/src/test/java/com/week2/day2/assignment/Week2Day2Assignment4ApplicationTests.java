package com.week2.day2.assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week2Day2Assignment4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
