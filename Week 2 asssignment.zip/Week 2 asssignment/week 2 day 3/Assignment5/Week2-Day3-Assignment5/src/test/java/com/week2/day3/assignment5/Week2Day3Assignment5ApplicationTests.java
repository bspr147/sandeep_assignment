package com.week2.day3.assignment5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week2Day3Assignment5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
