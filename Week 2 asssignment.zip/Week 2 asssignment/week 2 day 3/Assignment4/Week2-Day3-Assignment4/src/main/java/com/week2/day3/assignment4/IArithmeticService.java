package com.week2.day3.assignment4;

public interface IArithmeticService {
    int iadd(int x, int y);
    int isub(int x, int y);
    int imul(int x, int y);
    int idiv(int x, int y);
}
