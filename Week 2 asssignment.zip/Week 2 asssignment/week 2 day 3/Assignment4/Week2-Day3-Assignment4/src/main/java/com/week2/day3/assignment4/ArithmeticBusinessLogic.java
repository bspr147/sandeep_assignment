package com.week2.day3.assignment4;

@SuppressWarnings("unused")
public class ArithmeticBusinessLogic {
	private int a, b;
	private IArithmeticService ias;

	void setIAService(IArithmeticService ias) {
		this.ias = ias;
	}

	int add(int a, int b) {
		return ias.iadd(a, b);
	}

	int sub(int a, int b) {
		return ias.isub(a, b);
	}

	int mul(int a, int b) {
		return ias.imul(a, b);
	}
	
	int div(int a, int b) {
		int result = 0;
		if(a > b) {
			result = ias.idiv(a, b);
		}
		return result;
	}
}
