package com.week2.day3.assignment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*
#2. In Employee spring boot JPA example,
 use native query to retrieve all Employees whose salary is between certain values?*/

@SpringBootApplication
public class Week2Day3Assignment2Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day3Assignment2Application.class, args);
	}

}
