package com.week2.day3.assignment1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week2Day3Assignment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
