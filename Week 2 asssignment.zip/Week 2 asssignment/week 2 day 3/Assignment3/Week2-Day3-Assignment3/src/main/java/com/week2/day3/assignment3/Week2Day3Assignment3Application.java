package com.week2.day3.assignment3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*
#3. Make necessary changes in Employee Spring Boot REST project,
 to add Address entity class, and use one to one mapping between Employee and Address*/

@SpringBootApplication
public class Week2Day3Assignment3Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day3Assignment3Application.class, args);
	}

}
