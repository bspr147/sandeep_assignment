package com.week2.day5.assignment1.repo;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ScopeRepo2 {
	
	static int value = 0;
	
	public ScopeRepo2() {
		System.out.println("ScopeRepo2() Constructor : "+ value++);
	}

}
