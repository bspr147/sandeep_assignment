package com.week2.day5.assignment2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week2Day5Assignment2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
