package com.week2.day5.assignment2.controller;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.week2.day5.assignment2.model.Address;
import com.week2.day5.assignment2.model.Employee;

@RestController
@RequestMapping("/emp")
public class EmployeeController {
	
	@GetMapping("/all")
	public String met1() {
		RestTemplate restTemplate = new RestTemplate();
	     
	    final String baseUrl = "http://localhost:1515/employee/all";
	    URI uri = null;
		try {
			uri = new URI(baseUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
	 
	    ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
	     
	    System.out.println("Status code: "+result.getStatusCodeValue());
	    System.out.println("result: "+result.getBody());
	    
	    return "Status code: "+result.getStatusCodeValue()+"<br>result: "+result.getBody();
	}

	@GetMapping(value = "/add")
	public String postCheck()
	{
	    RestTemplate restTemplate = new RestTemplate();
	     
	    final String baseUrl = "http://localhost:1515/employee/add";
	    URI uri =  null;
		try {
			uri = new URI(baseUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
	    
		Address addr = new Address(111,"Warangal","Warangal Rural","Telangana", 506102);
	    Employee cust = new Employee(25,"RestTemplate",19000f, addr);
	    ResponseEntity<Employee> result = restTemplate.postForEntity(uri, cust, Employee.class);
	     
	    System.out.println("Status Code: "+result.getStatusCodeValue()+ result);
	    
	    return "Status Code: "+result.getStatusCodeValue()+ result;
	}
	
	@GetMapping(value = "/delete")
	public String deleteCheck()
	{
	    RestTemplate restTemplate = new RestTemplate();
	     
	    final String baseUrl = "http://localhost:1515/employee/26";
	    URI uri =  null;
		try {
			uri = new URI(baseUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
	     
		restTemplate.delete(uri);
		
		return "Employee details deleted from table";
	}

}
